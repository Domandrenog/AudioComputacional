
Aqui nesta pasta o nosso código principal, acompanhado dos comentários que consideramos necessários. 
No MATLAB offline, a função "bar()" não está disponível, por isso optamos por comentá-la para evitar erros.
Além do código, temos os sons desejados com taxas de amostragem de 44100Hz e 16000Hz, bem como o relatório.

Dentro da pasta "Professor Modificado", você encontrará o código fornecido pelo professor com as alterações necessárias para que funcione com nossos áudios e para que seja possível fazer comparações.

Para executar o código do professor, basta rodar o código "Main".